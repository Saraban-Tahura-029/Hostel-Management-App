Channel Link : https://www.youtube.com/@FlutterSync-0703

baseUrl - https://unt-house-management.onrender.com/unt

Note: Learn how to optimize your API server with intelligent management! In this tutorial, I demonstrate API integration, showcasing a unique feature: automatic server shutdown after 20 minutes of inactivity. Worried about server restarts? Fear not! I've added a 2-minute delay upon hitting the API again to ensure efficiency without overloading the server.

<img src="https://github.com/banku27/Youtube-Hostel-Management-App/assets/55456058/110a63c1-9599-4a13-8055-a28d40014143">

// Email Validation Regex : 

final emailRegex =
      RegExp(r'^[\w-]+(\.[\w-]+)*@[\w-]+(\.[\w-]+)*(\.[a-z]{2,})$');
