package com.example.hostel_management

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
